#Aleksandra Słaby
#169840
#L4
setwd("C:/Users/user/Desktop/IiAD/II semestr/Programowanie w R/Projekt 1")
getwd()

#Zadanie 1

dem <- read.csv("Demografia.csv", sep=",", dec=".", encoding = "UTF-8", header=FALSE)
col1 <- data.frame(dem[,1])
col1<-unique(col1)
col1<-col1[-1,]
col2<-data.frame(dem[,2])
col2<-unique(col2)
col3 <-dem[,3]
demografia <- matrix(col3, 32, 5, byrow=TRUE)
rownames(demografia)=col1
colnames(demografia)=c("2016", "2017", "2018", "2019", "2020")


#Zadanie 2 
list.files()
raport <- RAP_PRZYR_02_t #przy improcie odznaczyłam first row as names!
raport <- raport[-(1:6),-c(1,5,9)]
colnames(raport) <- raport[1,]
raport2 <- raport[,-1]
raport[,1]
raport[-1,]
rownames(raport2) <- c("Powierzchnia parku narodowego [ha]","Powierzchnia parku narodowego pod ochroną ścisłą [ha]",
                       "Powierzchnia parku narodowego pod ochroną czynną [ha] ","Powierzchnia parku narodowego pod ochroną krajobrazową [ha]",
                       "Powierzchnia gruntów leśnych parku narodowego [ha]", "Powierzchnia użytków rolnych parku narodowego [ha] ",
                       "Powierzchnia gruntów zadrzewionych i zakrzewionych parku narodowego [ha]", "Powierzchnia gruntów pod wodami parku narodowego [ha]",
                       "Powierzchnia gruntów pod wodami parku narodowego [ha] ", "Powierzchnia terenów pozostałych parku narodowego [ha]",
                       "Powierzchnia otuliny parku narodowego [ha]", "Powierzchnia strefy ochronnej zwierzyny parku narodowego [ha]")
                     
raport2010 <- data.frame(raport2[,1])
raport2012 <- data.frame(raport2[,3])
raport2014 <- data.frame(raport2[,5])
raport2016 <- data.frame(raport2[,7])
raport2018 <- data.frame(raport2[,9])
raport_zbiorczy <- data.frame(raport2010, raport2012, raport2014, raport2016, raport2018)
colnames(raport_zbiorczy)[1:5]<-c("2010","2012", "2014", "2016", "2018")
rownames(raport_zbiorczy) <- c("Powierzchnia parku narodowego [ha]","Powierzchnia parku narodowego pod ochroną ścisłą [ha]",
                       "Powierzchnia parku narodowego pod ochroną czynną [ha] ","Powierzchnia parku narodowego pod ochroną krajobrazową [ha]",
                       "Powierzchnia gruntów leśnych parku narodowego [ha]", "Powierzchnia użytków rolnych parku narodowego [ha] ",
                       "Powierzchnia gruntów zadrzewionych i zakrzewionych parku narodowego [ha]", "Powierzchnia gruntów pod wodami parku narodowego [ha]",
                       "Powierzchnia gruntów pod wodami parku narodowego [ha] ", "Powierzchnia terenów pozostałych parku narodowego [ha]",
                       "Powierzchnia otuliny parku narodowego [ha]", "Powierzchnia strefy ochronnej zwierzyny parku narodowego [ha]")

library(writexl)
write_xlsx(raport_zbiorczy, "Raport.xlsx") #działa

#Zadanie 3
trw <- tablice_trwania_zycia_1990_2020
trw <- trw[-c(1,2,4),]
colnames(trw) <- trw[1,]
trw<-trw[-1,]
moje_dane <- data.frame(trw[122,c(1,2,4,8)])
write_xlsx(moje_dane, "Kiedy_umre.xlsx")
write.table(moje_dane, file="Kiedy_umre2.txt")

#Zadanie 4

link1 <- "https://finance.yahoo.com/quote/AAPL/history?period1=1615593600&period2=1647129600&interval=1mo&filter=history&frequency=1mo&includeAdjustedClose=true"
link2 <- "https://finance.yahoo.com/quote/MSFT/history?period1=1615593600&period2=1647129600&interval=1mo&filter=history&frequency=1mo&includeAdjustedClose=true"            
link3 <- "https://finance.yahoo.com/quote/MA/history?period1=1615593600&period2=1647129600&interval=1mo&filter=history&frequency=1mo&includeAdjustedClose=true"
library(rvest)
apl <- read_html(link1)
AAPL <- html_table(apl)
Apple <- AAPL[[1]]
mic <- read_html(link2)
MICR <- html_table(mic)
Microsoft <-MICR[[1]]
mas <- read_html(link3)
MASC <- html_table(mas)
MasterCard <- MASC[[1]]
Apple <- Apple[-17,-c(2,3,4,6,7)]
Microsoft <- Microsoft[-17,-c(2,3,4,6,7)]
MasterCard <- MasterCard[-17,-c(2,3,4,6,7)]

Apple <-Apple[-c(2,6,10,14),]
MasterCard <-MasterCard[-c(3,7,11,15),]
Microsoft <-Microsoft[-c(2,6,10,14),]
Stocks<- data.frame(Apple, MasterCard[,2], Microsoft[,2])
colnames(Stocks)[2:4]<-c("Apple","MasterCard", "Microsoft")
write_xlsx(Stocks, "Stocks.xlsx")
